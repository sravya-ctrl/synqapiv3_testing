describe('User Login & Logout Test cases', () => {
    it('Login to the application with admin user', () => {
        cy.visit('https://synq.atforte.com/');
        cy.get('#email').type('admin@sales-people.com');
        cy.get('#password').type('123');
        cy.get("button[type='submit']").click();
        cy.contains('h1', 'Admin Dashboard');
        // to click on the back svg
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
        // click on the Usermanagement
        // Step 1: Click the first tab and wait for the URL change
        cy.get('.Sidebar_navItem__UO8yd').eq(0).click();  // Clicking the first tab
        cy.url().should('include', 'https://synq.atforte.com/admin');  
        // Step 2: Wait for any required elements or page content to load
        cy.wait(2000);  
        // Step 3: Now that the page has changed, click the second tab
        cy.get('.Sidebar_navItem__UO8yd').eq(1).click();  // Clicking the second tab
        cy.url().should('include', 'https://synq.atforte.com/admin/users');
        cy.wait(2000);

        //click on the anywhere on the page to hide the side bar 
        cy.get('.MuiTableRow-root.css-lt55q8').eq(0).click();
        cy.wait(2000);

        // Click on the user icon to logout
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerRight__ruL6A > svg').click();
        // Click on the logout button
        cy.get('button[type="button"]').eq(1).click();
    })


    it('Login to the application with Project Manager user',() => {
        cy.visit('https://synq.atforte.com/');
        cy.get('#email').type('pm@sales-people.com');
        cy.get('#password').type('123');
        cy.get("button[type='submit']").click();
        cy.contains('h1','Manager dashboard');

        // to click on the back svg
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
        //Click the first tab and wait for the URL change
        //Clicking the first tab
        cy.get('.Sidebar_navItem__UO8yd').eq(0).click();
        cy.url().should('include','https://synq.atforte.com/manager');
        cy.wait(2000);
        //Clicking the second tab
        cy.get('.Sidebar_navItem__UO8yd ').eq(1).click();
        cy.url().should('include','https://synq.atforte.com/manager/projects');
        //click on the anywhere on the page to open the side bar 
        cy.get('.MuiTableRow-root.css-lt55q8').eq(0).click();
        cy.wait(2000);
        // click on the first project from projects
        cy.get('.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71').eq(0).click();
        cy.wait(2000);
        // to click on the back svg
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
         //clicking the second tab
        cy.get('.Sidebar_navItem__UO8yd ').eq(1).click();
        cy.url().should('include','https://synq.atforte.com/manager/projects');

        //click on the anywhere on the page to open the side bar 
        cy.get('.MuiTableRow-root.css-lt55q8').eq(0).click();
        cy.wait(2000);
        //click on the 5th project from projects
        cy.get('table tbody tr').eq(4).find('td.MuiTableCell-root a').click();
        // to click on the back svg
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
        
        
        // click on the Setup page
        cy.get('.Sidebar_navItem__UO8yd').eq(2).click();
        cy.wait(2000);
        // click on the Web Portal Page
        cy.get('.Sidebar_navItem__UO8yd').eq(3).click();
        cy.wait(2000);
        // click on the Performance Page
        cy.get('.Sidebar_navItem__UO8yd').eq(4).click();
        // Click on the user icon
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerRight__ruL6A > svg').click();
        // Click on the logout button
        cy.get('button[type="button"]').eq(2).click();
    })

    it('Login to the application with Agent user', () => {
        cy.visit('https://synq.atforte.com/');
        cy.get('#email').type('agent@sales-people.com');
        cy.get('#password').type('123');
        cy.get("button[type='submit']").click();
        cy.contains('h1', 'Agent Dashboard');

         // to click on the back svg
         cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
        //Click the first tab and wait for the URL change
        //Clicking the first tab
        cy.get('.Sidebar_navItem__UO8yd').eq(0).click();
        cy.url().should('include','https://synq.atforte.com/agent');
        cy.wait(2000);
        //Clicking the second tab
        cy.get('.Sidebar_navItem__UO8yd ').eq(1).click();
        cy.url().should('include','https://synq.atforte.com/agent/projects');
        cy.wait(2000);
        // Click on the user icon
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerRight__ruL6A > svg').click();
        cy.wait(2000);
        // Click on the logout button
        cy.get('button[type="button"]').eq(10).click();
    })

    it('Login to the application with Client user', () => {
        cy.visit('https://synq.atforte.com/');
        cy.get('#email').type('kunde@sales-people.com');
        cy.get('#password').type('123');
        cy.get("button[type='submit']").click();
        cy.contains('h1', 'Client Dashboard');

        // to click on the back svg
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
        cy.wait(2000);
        // Click on the user icon
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerRight__ruL6A > svg').click();
        cy.wait(2000);
        // Click on the logout button
        cy.get('button[type="button"]').eq(1).click();
});

  it('Login to the application with Mailing Operator user', () => {
    cy.visit('https://synq.atforte.com/');
        cy.get('#email').type('qm@sales-people.com');
        cy.get('#password').type('123');
        cy.get("button[type='submit']").click();
        cy.contains('h1', 'Mailing Operator Dashboard');
        // to click on the back svg
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerLeft__UpIQS > svg').click();
        cy.wait(2000);
        // Click on the user icon
        cy.get('#root > div > div.header_header__z2nbC > div.header_headerRight__ruL6A > svg').click();
        cy.wait(2000);
        // Click on the logout button
        cy.get('button[type="button"]').eq(1).click();
  }) 


})
