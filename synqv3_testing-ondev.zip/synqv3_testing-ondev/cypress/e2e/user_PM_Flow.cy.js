function login() {
    cy.visit('https://synq.atforte.com/');
    cy.get('#email').type('pm@sales-people.com');
    cy.get('#password').type('123');
    cy.get("button[type='submit']").click();
    cy.contains('h1', 'Manager dashboard');

    //Click the first tab and wait for the URL change
    //Clicking the first tab
    cy.get('.Sidebar_navItem__UO8yd').eq(0).click();
    cy.url().should('include', 'https://synq.atforte.com/manager');
    cy.wait(2000);
    //Clicking the second tab
    cy.get('.Sidebar_navItem__UO8yd ').eq(1).click();
    cy.url().should('include', 'https://synq.atforte.com/manager/projects');
    //click on the anywhere on the page to open the side bar 
    cy.get('.MuiTableRow-root.css-lt55q8').eq(0).click();
    cy.wait(2000);
}


it('check each record data is matching with pagecount', () => {

    login();
    // Find all clickable cells in the table
    cy.get('.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71')
        .then((cells) => {
            const total = cells.length;
            cy.log(`Total project rows: ${total}`);

            // Click the "rows per page" dropdown button
            cy.get('svg[class*="MuiSelect-icon"]').parent().click();
            // Then click the "100" option from the dropdown
            cy.contains('li', '100').click();
            cy.wait(5000);
            for (let i = 0; i < total; i++) {
                // Visit the page again before each iteration
                cy.visit('https://synq.atforte.com/manager/projects');
                // Click the current cell
                cy.get('.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71')
                    .eq(i)
                    .find('a')
                    .scrollIntoView()
                    .should('be.visible')
                    .click();
                cy.wait(5000);

                cy.get('body').then(($body) => {
                    const kampagneElement = $body.find('p:contains("Accounts in kampagne:")');

                    if (kampagneElement.length > 0) {
                        const text = kampagneElement.text().trim();
                        const kampagneCount = parseInt(text.split(':')[1].trim(), 201);
                        const kampagneLastTwo = kampagneCount.toString().slice(-2);
                        cy.log('Kampagne Count:', kampagneCount);

                        // pagination comparison 
                        cy.get('span.MuiTypography-root.MuiTypography-body2.MuiTypography-alignCenter', { timeout: 5000 })
                            .invoke('text')
                            .then((paginationText) => {
                                const paginationCount = parseInt(paginationText.split('of')[1].trim().replace(/,/g, ''), 201);
                                const paginationLastTwo = paginationCount.toString().slice(-2);

                                //  Compare only last two digits
                                expect(kampagneLastTwo).to.equal(paginationLastTwo);
                            });

                    } else {
                        cy.log('❗️"Accounts in kampagne:" text not found, skipping...');
                    }
                });

                // Scroll to top
                cy.window().then((win) => {
                    win.scrollTo({ top: 0, behavior: 'smooth' });
                });
                // Allow layout to adjust
                cy.wait(5000);
                // Go back to the table
                cy.go('back');
            }
        });
});


it('clicking on button to redirect setup page', () => {

    login();
    cy.get('table').should('be.visible');

    cy.get('.MuiTableRow-root').not('.MuiTableRow-head').then(($rows) => {
        const rowCount = $rows.length;
        // Use a Cypress chain to click each row button and return
        Cypress._.times(rowCount, (index) => {
            cy.log(`Processing row ${index + 1}`);

            // Re-fetch row every time to avoid stale element reference
            cy.get('.MuiTableRow-root').not('.MuiTableRow-head').eq(index).then(($row) => {
                cy.wrap($row)
                    .find('.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeMedium.css-mfslm7')
                    .first()
                    .scrollIntoView()
                    .click({ force: true });
                cy.wait(4000);

                // Navigate back to the projects list
                cy.get('.Sidebar_navItem__UO8yd').eq(1).click();
                cy.url().should('include', '/manager/projects');
                cy.wait(2000);
            });
        });
    });
});


function scrollTable() {
    // Scroll to the top of the table first
    cy.get('.MuiTableContainer-root')
        .scrollTo('top', { duration: 800 });

    // Then scroll to the bottom
    cy.get('.MuiTableContainer-root')
        .scrollTo('bottom', { duration: 1000 });

    cy.wait(500);
}

function clickNextPageAndScroll() {
    function next() {
        scrollTable();

        // Get the Next Page button
        cy.get('button[aria-label="Go to next page"]').then($btn => {
            // Check if disabled by aria-disabled or class
            const isDisabled =
                $btn.attr('aria-disabled') === 'true' ||
                $btn.hasClass('Mui-disabled') ||
                $btn.prop('disabled');

            if (!isDisabled) {
                cy.wrap($btn)
                    .click({ force: true });
                // Wait for the new page to load
                cy.get('table tbody tr').first().should('be.visible');

                // Recursively call next for next page
                next();
            } else {
                cy.log('Reached last page, stopping pagination.');
            }
        });
    }
    next();
}

it('companies list filtering', () => {

    login();
    //Clicking the second tab
    cy.get('.Sidebar_navItem__UO8yd ').eq(1).click();
    cy.url().should('include', 'https://synq.atforte.com/manager/projects');
    //click on the anywhere on the page to open the side bar 
    cy.get('.MuiTableRow-root.css-lt55q8').eq(0).click();
    cy.wait(2000);
    // Find all clickable cells in the table
    cy.get('.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71')
    // To click on first record    
    cy.get('#root > div > div.main-card.flex-grow-1.d-flex.gap-4.mt-2 > div.flex-grow-1 > div > div.main-content > div > div.MuiTableContainer-root.css-ew3gae > table > tbody > tr:nth-child(1) > td.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71').eq(0).click();
    cy.wait(8000);

    // click on the  dropdown
    cy.get('#root > div > div.main-card.flex-grow-1.d-flex.gap-4.mt-2 > div.flex-grow-1 > div > div.main-content > div.Materialtables_tablesTopCard__6rVZs > div.Materialtables_filtersList__0NEhA > div:nth-child(1) > div > div').eq(0).click();

    // Selecting Not Assigned
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').contains('Not Assigned').should('be.visible').click();
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // Scroll to top
    cy.window().then((win) => {
        win.scrollTo({ bottom: 0, behavior: 'smooth' });
    });

    cy.get('.MuiTablePagination-root').within(() => {
        cy.get('svg[class*="MuiSelect-icon"]').parent().click();
    });

    // Select "100" rows per page 
    cy.get('li[data-value="100"]').click();

    clickNextPageAndScroll();
    cy.wait(6000);

    // click on the  dropdown
    cy.get('#root > div > div.main-card.flex-grow-1.d-flex.gap-4.mt-2 > div.flex-grow-1 > div > div.main-content > div.Materialtables_tablesTopCard__6rVZs > div.Materialtables_filtersList__0NEhA > div:nth-child(1) > div > div').eq(0).click();
    // Selecting Account Locked
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').contains('Account Locked').should('be.visible').click({ force: true });
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on the  dropdown
    cy.get('#root > div > div.main-card.flex-grow-1.d-flex.gap-4.mt-2 > div.flex-grow-1 > div > div.main-content > div.Materialtables_tablesTopCard__6rVZs > div.Materialtables_filtersList__0NEhA > div:nth-child(1) > div > div').eq(0).click();
    // Selecting 
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').contains('sales agent').should('be.visible').click({ force: true });

    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();

    cy.wait(3000);
    // Scroll to top
    cy.window().then((win) => {
        win.scrollTo({ bottom: 0, behavior: 'smooth' });
    });

    cy.get('.MuiTablePagination-root').within(() => {
        cy.get('svg[class*="MuiSelect-icon"]').parent().click();
    });

    // Select "100" rows per page from the dropdown (if it exists)
    cy.get('li[data-value="100"]').click();
    clickNextPageAndScroll();
    cy.wait(3000);

    // Scroll to top 
    cy.window().then((win) => {
        win.scrollTo({ top: 0, behavior: 'smooth' });
    });
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    // selecting Lead type
    cy.get('.MuiSelect-root').eq(1).click();
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').contains(/^B$/).click({ force: true });
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.get('.MuiTableContainer-root')
        .scrollTo('right', { duration: 500 });
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    // click on Tranche dropdown
    cy.get('.MuiSelect-root').eq(2).click();
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').eq(2).click();
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // Scroll to top 
    cy.window().then((win) => {
        win.scrollTo({ bottom: 0, behavior: 'smooth' });
    });
    cy.get('.MuiTablePagination-root').within(() => {
        cy.get('svg[class*="MuiSelect-icon"]').parent().click();
    });
    // Select "100" rows per page 
    cy.get('li[data-value="100"]').click();
    clickNextPageAndScroll();
    cy.wait(6000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();


    // click on vertical dropdown
    cy.get('.MuiSelect-root').eq(3).click();
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').eq(4).click();
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    // selecting land 
    cy.get("input[id='search2']").eq(0).type('de');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();    // NO RECORDS FOUND
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    // selecting PLZ von
    cy.get("input[id='search2']").eq(1).type('100000');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    cy.wait(3000);
    //selecting PLZ bis 
    cy.get("input[id='search2']").eq(2).type('20000');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // Scroll to top 
    cy.window().then((win) => {
        win.scrollTo({ bottom: 0, behavior: 'smooth' });
    });
    cy.get('.MuiTablePagination-root').within(() => {
        cy.get('svg[class*="MuiSelect-icon"]').parent().click();
    });
    // Select "100" rows per page 
    cy.get('li[data-value="100"]').click();
    clickNextPageAndScroll();
    cy.wait(6000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    // selecting MA von
    cy.get("input[id='search2']").eq(3).type('250');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();

    // selecting MA bis
    cy.get("input[id='search2']").eq(4).type('250');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on Reset button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(1).click();
});



it('filtering with all the data', () => {
    login();
    //Clicking the second tab
    cy.get('.Sidebar_navItem__UO8yd ').eq(1).click();
    cy.url().should('include', 'https://synq.atforte.com/manager/projects');
    //click on the anywhere on the page to open the side bar 
    cy.get('.MuiTableRow-root.css-lt55q8').eq(0).click();
    cy.wait(2000);
    // Find all clickable cells in the table
    cy.get('.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71')
    // To click on first record    
    cy.get('#root > div > div.main-card.flex-grow-1.d-flex.gap-4.mt-2 > div.flex-grow-1 > div > div.main-content > div > div.MuiTableContainer-root.css-ew3gae > table > tbody > tr:nth-child(1) > td.MuiTableCell-root.MuiTableCell-body.MuiTableCell-alignLeft.MuiTableCell-sizeMedium.css-67wk71').eq(0).click();
    cy.wait(8000);
    // click on the  dropdown
    cy.get('#root > div > div.main-card.flex-grow-1.d-flex.gap-4.mt-2 > div.flex-grow-1 > div > div.main-content > div.Materialtables_tablesTopCard__6rVZs > div.Materialtables_filtersList__0NEhA > div:nth-child(1) > div > div').eq(0).click();
    // Selecting Not Assigned
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').contains('Not Assigned').should('be.visible').click();
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // selecting Lead type
    cy.get('.MuiSelect-root').eq(1).click();
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').contains(/^B$/).click({ force: true });
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on Tranche dropdown
    cy.get('.MuiSelect-root').eq(2).click();
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').eq(2).click();
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // click on vertical dropdown
    cy.get('.MuiSelect-root').eq(3).click();
    cy.get('.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.MuiMenuItem-root.MuiMenuItem-gutters.css-5dycmn').eq(4).click();
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);
    // selecting land 
    cy.get("input[id='search2']").eq(0).type('de');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();    // NO RECORDS FOUND
    cy.wait(3000);
    // selecting PLZ von
    cy.get("input[id='search2']").eq(1).type('100000');
    // click on filter button
    cy.get('.Materialtables_optionsButton__KTzRG').eq(0).click();
    cy.wait(3000);

})




