const path = require('path');

   // Webpack is used to bundle and optimize the code.

module.exports = {
  mode: 'testing',
  entry: './src/ComponentName.cy.js', // Adjust this to your project structure
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: 'babel-loader',
      },
    ],
  },
  resolve: {
    extensions: ['.js', '.jsx'],
  },
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist'),
  },
};
