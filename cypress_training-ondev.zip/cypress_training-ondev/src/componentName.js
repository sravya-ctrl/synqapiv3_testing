import React from 'react';
// Your component should look like this:
const ComponentName = ({ onClick, label }) => {
  return <button onClick={onClick}>{label}</button>;
};

export default ComponentName;
