module.exports = {
    presets: [

        //  Babel is used to transpile the JavaScript code, 
        // making it compatible with older browsers
      '@babel/preset-env',   // Supports the latest JavaScript features
      '@babel/preset-react'  // Enables JSX support
    ]
  };
  