describe("dummy data", () => {
  
    it.only("example page", () => {

        cy.visit("http://13.232.29.116/")
        cy.wait(18000)
        cy.get('#header-and-modal > div.container-fluid.d-flex.justify-content-between.align-items-center.header > div.menu-toggle > img').click();
        cy.get("#menuModal > div.modal-content > div.modal-body > div > div > div.col-md-6.main-right1 > div.main-right-contact > a > div").click();

    })
  
})
 