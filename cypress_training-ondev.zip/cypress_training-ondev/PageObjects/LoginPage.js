// PageObjects/LoginPage.js
class LoginPage {

    // By refer this test page to identify the elements
    setUserName(username) {
        cy.get('#username').type(username);
    }

    setPassword(password) {
        cy.get('#password').type(password);
    }

    clickSubmit() {
        cy.get('button[type="submit"]').click();
    }

    verifyLogin() {
        cy.get('#successMessage').should('have.text', 'Login successful!');
    }
}

export default LoginPage;  // Correct export
