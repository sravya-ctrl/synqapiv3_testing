// PageObjects/LoginPage.js
class LoginPage {

     // By refer this test page to identify the elements
    // another way to call the property values 
    txtUserName = '#username';
    txtPassword = '#password'
    btnSubmit = 'button[type="submit"]'
    lblMsg = '#successMessage'

   // By refering this keyword we are calling current class properties
    setUserName(username) {
        cy.get(this.txtUserName).type(username);
    }

    setPassword(password) {
        cy.get(this.txtPassword).type(password);
    }

    clickSubmit() {
        cy.get(this.btnSubmit).click();
    }

    verifyLogin() {
        cy.get(this.lblMsg).should('have.text', 'Login successful!');
    }
}

export default LoginPage;  // Correct export
