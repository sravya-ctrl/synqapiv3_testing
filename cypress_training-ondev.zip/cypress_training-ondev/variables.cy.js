describe('Variables', () => {
    //variables are used for -  You can define variables to store values, objects, or even functions that you can reuse throughout your test code
    it('brief about variables', () => {
        // In cypress we normally user javascript variables are 3 
        // var
        // let
        // const

        //  :: The scope of var - we change the value whenever we need to change

        // Declaring a variable
        var testing;
        // defining a variable
        var testing = 'Cypress'
        //with log() print the value of variable in cypress page
        cy.log(testing)
        //defining new value to the existed variable
        var testing = 'Javascript'
        //the variable value has been changed to the new defined value
        cy.log(testing)


        // :: The scope of let - we cannot change the value once we define with let but we can change the value without giving the let 
        let learning = 'Cypress'
        cy.log(learning)
        // ERROR : Cannot redeclare block-scoped variable 'learning'.ts(2451)
        // let learning = 'Selenium'
        //cy.log(learning)
        //we can change the value without giving the let
        learning = 'Selenium'
        cy.log(learning)


        // :: The scope of const - we cannot change the value once we define it   
        const practice = 'Cypress'
        cy.log(practice)
        // ERROR : Cannot redeclare block-scoped variable 'practice'.ts(2451)
        // const practice ='sdfg'
        //cy.log(practice)

        // :: SCOPES - Global , Function , Block 

        // defining a global variable 
        var global = 'testing global page'
        function variable() {
            // defining a function variable
            let functional = 'function Call'
            if (10 < 20) {
                // defining a variable within block access within block only
                let letScope = 'usingLet'
                cy.log(letScope)
                // we can access the global variable anywhere in the page
                cy.log(global)
                // we can access the global anywhere within the function only
                cy.log(functional)
            }
            // we cannot access the vaiable using let out side of the block within function
            // cy.log(letScope)
            cy.log(functional)


            if (10 < 20) {
                var varscope = 'usingVar'
                cy.log(varscope)
            }
            // we can access the vaiable using var out side of the block
            cy.log(varscope)


            if (10 < 20) {
                const constScope = 'usingConst'
                cy.log(constScope)
            }
            // we cannot access the vaiable using const out side of the block
            //cy.log(constScope)
        }
        variable();
    })

})