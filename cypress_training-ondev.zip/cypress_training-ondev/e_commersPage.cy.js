//beforeEach()
function userLogin(url){
    cy.visit(url);
    cy.get('#user-name').type('standard_user');
    cy.get('#password').type('secret_sauce');
    cy.get('#login-button').click();
}

function userInvalidLogin(url) {
    cy.visit(url);
    cy.get('#user-name').type('standard');
    cy.get('#password').type('secret');
    cy.get('#login-button').click();
    cy.get('#login_button_container > div > form > div.error-message-container.error > h3').should('be.visible');
    cy.get('#login_button_container > div > form > div.error-message-container.error > h3').should('contain', 'Epic sadface: Username and password do not match any user in this service');
}

function productPurchase(url) {
    userLogin(url);
    //cy.visit(url);
    cy.get('#item_1_title_link').should('have.text','Sauce Labs Bolt T-Shirt').click();
    cy.get('#add-to-cart').click();
}

function clickOnBackToProducts(url){
      productPurchase(url);
        cy.get('#back-to-products').click();
}
function checkoutProcess(url) {
    userLogin(url);
   cy.get('#shopping_cart_container').click();
   cy.get('#checkout').should('contain','Checkout').click();
   cy.get('#first-name').type('standar');
   cy.get('#last-name').type('_user');
   cy.get('#postal-code').type('500032');
   cy.get('#continue').click();
   cy.get('#finish').click();
   cy.get('#back-to-products').click();
}
function loginWithoutCredentials() {
    cy.visit('https://www.saucedemo.com/');
    cy.get('#login-button').click();
    cy.get('#login_button_container > div > form > div.error-message-container.error > h3').should('be.visible').and('contain','Epic sadface: Username is required');
}

function loginwithOnlyUsername() {
    cy.visit('https://www.saucedemo.com/');
    cy.get('#user-name').type('standard_user');
    cy.get('#login-button').click();
    cy.get('#login_button_container > div > form > div.error-message-container.error > h3').should('contain', 'Epic sadface: Password is required'); 
}

function loginwithOnlyPassword() {
    cy.visit('https://www.saucedemo.com/');
    cy.get('#password').type('secret_sauce');
    cy.get('#login-button').click();
    cy.get('#login_button_container > div > form > div.error-message-container.error > h3').should('contain','Epic sadface: Username is required');
}
    
describe('User Login, Product Purchase, and Checkout Process', () => {

// beforeEach(() => {
//     userLogin('https://www.saucedemo.com/');
// })

    it('User Login', () => {
        userLogin('https://www.saucedemo.com/');
        cy.get('body > noscript').should('be.visible').click({ force: true });
    })
    it('User Invalid Login', () => {
       userInvalidLogin('https://www.saucedemo.com/');
    })
    it('Product Purchase', () => {
        productPurchase('https://www.saucedemo.com/');
    })
    it('Back to Products', () => {
        clickOnBackToProducts('https://www.saucedemo.com/');
    })
    it('User checkout Process', () => {
        checkoutProcess('https://www.saucedemo.com/');
    })
    it('Login without credentials', () => {
        loginWithoutCredentials();
    })
    it('User Login with only usename', () => {
        loginwithOnlyUsername();
    })
    it('User login with only password', () => {
        loginwithOnlyPassword();
    })
})