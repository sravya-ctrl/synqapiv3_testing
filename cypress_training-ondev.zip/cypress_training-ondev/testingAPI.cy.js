const dataJson = require('../../fixtures/example')

describe('API testing using cypress', () => {

     it('HTTP GET call',() => {

        cy.request('GET','https://fake-store-api.mock.beeceptor.com')
        .its('status')
        .should('equal',200);
    })

    it('POST',() => {
        cy.request( {
            method: 'POST', 
            url: 'https://crypto-wallet-server.mock.beeceptor.com',
            body: {
                title: "Post call",
                body: "This is post call",
                userId: 1
            }
        })

        .its('status')
        .should('equal',200);
    })

        it('PUT',() => {
            cy.request({
                method: 'PUT',
                url:'https://fake-store-api.mock.beeceptor.com',
                body: {
                    title: 'PUT call',
                    body: 'This is PUT call',
                    userId: 1,
                    id: 1
                }
            })
            .its('status')
            .should('equal',200);
        })

        it('DELETE',() => {
            cy.request({ 
                method: 'DELETE',
                url: 'https://posthook-api.mock.beeceptor.com',
            })
            .its('status')
            .should('equal',200);
        })

    // ===================================================================


      it('Hard coded json object', () => {

        const requestBody = {
             name: 'Sravya',
             email: 'sravya123@gmail.com',
             location: "hyd"
        }

        cy.request( {
             mathod: 'POST',
             url: 'https://crypto-wallet-server.mock.beeceptor.com',
             body: requestBody
        })
        //.then((response) => {
            // expect(response.status).to.eq(200)
            // expect(response.body.name).to.eq('Sravya')
            // expect(response.body.email).to.eq('sravya123@gmail.com')
            // expect(response.body.location).to.eq('hyd')
      })

    // =====================================================================================


     it('Dynamically generating json object',() => {

        const requestBody={
            name: Math.random().toString(6).substring(2),
            email: Math.random().toString(6).substring(2)+"@gmail.com",
            location: "hyd"
        }

        cy.request ( {
            mathod: 'POST',
            url:'https://crypto-wallet-server.mock.beeceptor.com',
            body: requestBody
        })
        .then( (response) => {
            expect(response.status).to.eq(200)
            expect(response.body.name).to.eq(requestBody.name)
            expect(response.body.email).to.eq(requestBody.email)
             expect(response.body.location).to.eq(requestBody.location)
        })
     })

    // ========================================================================

    it('Using Fixtures', () => {
        cy.fixture('example').then( (data) => {
            const requestBody = data;

        cy.request({ 
            method: 'POST',
            url: 'https://crypto-wallet-server.mock.beeceptor.com',
            body: requestBody
        })
        .then( (response) => {
           expect(response.status).to.eq(200)
           expect(response.body.name).to.eq(requestBody.name)
           expect(response.body.email).to.eq(requestBody.email)
            expect(response.body.location).to.eq(requestBody.location)

            expect(response.body).has.property('name',requestBody.name)
            expect(response.body).to.have.property('email')
        })

        })
    })

    // ==========================================================================

    const rqueryParam = { page: 2 };

    it('Passing Query parameters', () => {

        cy.request( {
            method: 'POST',
            url: 'https://crypto-wallet-server.mock.beeceptor.com',
            qs: rqueryParam
        })
        .then( (response) => {
            expect(response.status).to.eq(200)
            expect(response.status).eq(200)
            expect(response.body.page).to.eq(2);
            expect(response.body.data).has.length(6);
            expect(response.body.data[0]).have.property('id',7);
            expect(response.body.data[0]).has.property('first_name','Salina');
        })
    })

    // ===================================================================================

    let authToken = null;
    before('Creating access token', () => {

        cy.request( {
            method: 'POST',
            url: 'https://crypto-wallet-server.mock.beeceptor.com',
            headers: {
                'Content-Type': 'application/json'
            },
            body: {
                name: 'SravyaSalina',
                email: Math.random().toString(6).substring(2)+"@gmail.com"
            }
        }) .then((response) => {
            authToken = response.body.accessToken;
        })
    })

    before('creating new order', () => {
        cy.request( {
            method: 'POST',
            url: 'https://crypto-wallet-server.mock.beeceptor.com',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer '+authToken
            },
            body: {
                name: 'SravyaSalina',
                email: Math.random().toString(6).substring(2)+"@gmail.com"
            }
        }) .then((response) => {
            // expect(response.status).to.eq(200);
           // expect(response.body.created).to.eq(true);
        })  
        })

        it('Fetching tech orders',() => {
            cy.request( {
                    method: 'GET',
                    url: 'https://crypto-wallet-server.mock.beeceptor.com',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer '+authToken
                    },
                    cookies: {
                        'cookiesName': 'mycookie'
                    }
            }).then (( response)=> {
                expect(response.status).to.eq(200);
                expect(response.body).has.length(1);
            })
        })

    //===============================================================================   

     it('Parsing simple JSON response', () => {

        cy.request( {
            method: 'GET',
            url: '',      
        })
        .then((response)=> {
            // expect(response.status).to.eq(200)
            // expect(response.body[0].id).to.equal(1)
            // expect(response.body[0].title).to.equal('')
            // expect(response.body[0].price).to.equal(123.657)
            // expect(response.body[0].rating.rate).to.equal(3.9)   
        })
     })

    // If I am trying to validate the last record ex:20 
    // we can change the index and values
    expect(response.body[19].id).to.equal(1)

     it.only('Parsing complex JSON response',() => {
        let totalPrice = 0;
        cy.request({
            method: 'GET',
            url: '',
            qs:{limit:5}
        })
        .then((response) => {
            expect(response.status).to.equal(200)

            response.body.forEach(element => {
               totalPrice = totalPrice + element.price;
            });
            expect(totalPrice).to.equal(4657);

     })
    })

    // =======================================================================
    // install ajv library for JSON type schema validations
    // npm install ajv

    const ajv = require('ajv')
    const avj = new ajv()   

    it('Schema validation against response', () => {
        cy.request({

            method: 'GET',
            url: '',
        })
        .then((response) => {
        const schema = {
      // schema data

        }

        const validate = avj.compile(schema)
        const isValid = validate(response.body)
        expect(isValid).to.be.true;
        })
    })

    // ===================================================================

    it('Basic Authentication', () => {
        cy.request({
            method: 'GET',
            url: '',
            auth: {
                user: 'postman',
                pass: 'password'
            }
        })
        .then((response) => {

            expect(response.status).to.eq(200)
            expect(response.body.authenticated).to.eq(true);
        })
    })

    it('Digest Authentication', () => {
        cy.request({
            method: 'GET',
            url: '',
            auth: {
                user: 'postman',
                pass: 'password',
                mathod:'digest'
            }
        })
        .then((response) => {

            expect(response.status).to.eq(200)
            // expect(response.body.authenticated).to.eq(true);
        })

     })

     const token='give the newly genrated token from github'

    it('Bearer token Authentication', () => {
        cy.request({
            method: 'GET',
            url: '',
            headers: {
                Authorization: 'Bearer'+ token
            }
        })
        .then((response) => {

            expect(response.status).to.eq(200)
            // expect(response.body.authenticated).to.eq(true);
        })
    })

    // // ======================================================================

    const accessToken = "";
    it('Get Oauth2 access token',() => {
        cy.request({
            method:'POST',
            url: '',
            qs:{
                client_id:'',
                clinet_secret:'',
                code:''
            }
        })
        .then((response) => {
            response.body.split('&');
            accessToken = params[0].split("=")[1]
        })

        it('OAuth2 request',() => {
            cy.request ({
                method: 'GET',
                url: '',
                headers: {
                    Autherization: 'Bearer '+accessToken
                }
            })
            .then((response) => {
                expect(response.status).to.eq(200)
                expect(response.body[0].id).to.equal(567)
            })
        })
    })

    // =====================================================================


    // Examples :

    it('get users', () => {
        cy.request({
            method: 'GET',
            url: 'https://gorest.co.in/public/v2/users',
            headers: {
                Authorization: 'Bearer d79e13993a9cbdbd79fddeb95154e72d10b906765516b9b28003421d7cf571ed'
            }
        })
            .then((response) => {
                expect(response.status).to.eq(200)
                expect(response.body.meta.pagination.limit).to.eq(20)
            })
    })

    it('get users by id test', () => {
        cy.request({
            method: 'GET',
            url: 'https://gorest.co.in/public/v2/users/2',
            headers: {
                'Authorization': 'Bearer d79e13993a9cbdbd79fddeb95154e72d10b906765516b9b28003421d7cf571ed'
            }
        }).then((response) => {
            expect(response.status).to.eq(200)
            expect(response.body.data.name).to.eq('')
        })
    })

    // ==========================================================================

    let randomText = Math.random().toString(6).substring(2) + "@gmail.com"

    it('Create user test using POST call', () => {

        cy.fixture('example').then((payload) => {

            cy.request({
                method: 'POST',
                url: 'https://gorest.co.in/public/v2/users',
                headers: {
                    'Authorization': 'Bearer d79e13993a9cbdbd79fddeb95154e72d10b906765516b9b28003421d7cf571ed'
                },
                body: {
                    //    "name": "Test Automation",
                    //    "gender":"female",
                    //    "email": randomText,
                    //    "status": "active"

                    // By using fixture file calling the property values
                    "name": payload.name,
                    "gender": payload.gender,
                    "email": randomText,
                    "status": payload.status
                }
            }).then((response) => {
                cy.log(JSON.stringify(response))
                expect(response.status).to.eq(201)
                // expect(response.body.data).has.property('email', randomText)
                // expect(response.body.data).has.property('name','Test Automation')
                // expect(response.body.data).has.property('gender','female')

                // By using fixture file calling the property values
                cy.log(JSON.stringify(response))
                expect(response.status).to.eq(201)
                expect(response.body.data).has.property('email', randomText)
                expect(response.body.data).has.property('name', payload.name)
                expect(response.body.data).has.property('gender', payload.gender)
            }).then((response) => {

                const userId = response.body.data.id

                cy.request({
                    method: 'GET',
                    url: 'https://gorest.co.in/public/v2/users/' + userId,
                    headers: {
                        'Authorization': 'Bearer d79e13993a9cbdbd79fddeb95154e72d10b906765516b9b28003421d7cf571ed'
                    },
                }).then((response) => {
                    expect(response.body.data).has.property('id', userId)
                    expect(response.body.data).has.property('name', payload.name)
                    expect(response.body.data).has.property('status', payload.status)

                })

            })

        })
    })
})



