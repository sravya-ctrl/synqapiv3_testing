describe('Handling Web Tables',() => {
    it('Check number of Rows & Columns',() => {

        cy.visit('https://tablepress.org/demo/');
        
    })



})