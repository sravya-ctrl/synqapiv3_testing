describe('Login API Automation Test', () => {

    // Testcase Scenarios : 
        // Valid Credentials
        // Incorrect Credentials
        // Missing Username , password
        // Empty Username , Password
        // Incorrect HTTP methods
        // Account Locked - Too many failed login attempt 
        // Expired/Invalid session token
        // Password complexity validation
        // Case sensitivity of usename/password
        // Successful login with 2FA (Two-Factor Authentication)
        // Login with different user roles

    // Define the login API endpoint
    const loginUrl = 'https://dummyjson.com/auth/login';  
  
    it('should login successfully with correct credentials', () => {
      // Send a POST request to the login endpoint
      cy.request({
        method: 'POST',
        url: loginUrl,
        body: {
          username: 'testuser',        
          password: 'password123'   
        }
      }).then((response) => {
        // Assert that the response status is 200 (OK)
        expect(response.status).to.eq(200);       // Status : 400 Bad Request - Invalid credentials
  
        // Assert that the response body contains a token or success message
        expect(response.body).to.have.property('username');
        expect(response.body.password).to.be.a('string');
      });
    });
  
    it('should return 401 for invalid credentials', () => {
      cy.request({
        method: 'POST',
        url: loginUrl,
        body: {
          username: 'wronguser',   // Invalid username
          password: 'wrongpass'    // Invalid password
        },
        failOnStatusCode: false // Allow the request to continue even if the status code is 401
      }).then((response) => {
        // Assert that the response status is 401 (Unauthorized)
        expect(response.status).to.eq(401);       //  Status : 400 - Invalid credentials 
  
        // Assert that the response body contains an error message
        expect(response.body.message).to.eq('Invalid username or password');
      });
    });
  
    it('should return 400 if username or password is missing', () => {
      cy.request({
        method: 'POST',
        url: loginUrl,
        body: {
          username: '',  // Missing username
          password: ''   // Missing password
        },
        failOnStatusCode: false // Allow the request to continue even if the status code is 400
      }).then((response) => {
        // Assert that the response status is 400 (Bad Request)
        expect(response.status).to.eq(400);    
  
        // Assert that the response body contains an appropriate error message
        expect(response.body.message).to.eq('Username and password are required');
      });
    });
  });
  