// In cypress directives we are used to create a testscript They allow to work with the web elements in your tests, 
// do what is necessary, validate the expected results, and run the tests sequentially.
// with cypress commander library has a robust command set, each designed for different situations or scenarios

// :: cypress commands are : 
// cy.visit() , cy.get(), cy.contains(), cy.click(), cy.type(), cy.clear(), cy.url(), cy.title(), cy.reload(), cy.wait()
// cy.should(), cy.intercept(), cy.request(), cy.route(), cy.fixture(), cy.readFile(), cy.writeFile(), cy.scrollTo(), cy.hover(), 

// use describe() to organize and structure our test suites
// describe is from framework as Mocha, which Cypress is built on 
describe('Commands', () => {

    it('Basic commands in cypress', () => {
        // using cy.visit() command to visit the web page
        cy.visit('https://practicetestautomation.com/practice-test-login/')

        // The cy.scrollTo() command is used to scroll the browser window or an element to the specified position
        cy.scrollTo(0, 200)

        // The cy.get() command is used to retrieve one or more elements from the webpage DOM with cy.type() text into an input field or text area.
        cy.get('input[type="text"]').type("student")
        cy.get('input[type="password"]').type("Password1234")

        // The cy.contains() command is used to retrieve specific text like submit 
        cy.contains('Submit')

        // The cy.click() command is used to a click event on an element. clicking submit button
        cy.get('.btn').click();
        // cy.wait(5000)
        // cy.get('.btn').focus()
        // cy.wait(5000)
        // cy.get('.btn').blur()

        // The cy.clear() command is used to clear the value of an input field password
        cy.get('input[type="password"]').type("Password123").clear();

        // The cy.url() is used to get the correct url from the page with assert
        cy.url().should('include', 'practice')

        // The cy.title() is used to retrieve or assert the current title of the page
        cy.scrollTo(300, 0)
        cy.title().should('eq', 'Test Login | Practice Test Automation')

        // The cy.wait() is used to wait for a specified amount of time 
        cy.wait(5000)    // Wait for 5 seconds

        // The cy.reload() command is used to reload the current page in the browser.
        cy.reload();

        // The cy.should() is used to assert the lable is same as specified or not
        cy.get('#form > div:nth-child(1) > label').should('have.text', 'Username')

        // The cy.intercept() is used to intercept all GET requests to the /api/data endpoint.
        // The . reply method is then used to return a mock response with a status code of 200 and a JSON body of { data: 'Test Data' }.
        // cy.intercept('GET', '/api/users', { fixture: 'example.json' })

        // The cy.request() command is used to send a network request without loading the page.
        cy.request('POST', 'https://jsonplaceholder.typicode.com/posts', { username: 'johndoe', password: 'mypassword' })

        // The cy.fixture() command is used to load data from a fixture file.
        cy.fixture('example.json')

        // cy.writeFile() is used to write the data to a file
        cy.writeFile("JsonFileData.json", { Data1: "Value1", Data2: "Value2" })

        // cy.readFile() is used to read the content of a file and passing it to callback function
        // cy.readFile("JsonFileData.json").then( (data) => 
        cy.wait(3000)

        // The cy.hover() command is used to trigger a hover event on the specified element.
        cy.get('#menu-item-20').trigger('mouseover')


    })

})
