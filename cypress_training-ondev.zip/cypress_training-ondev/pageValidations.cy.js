describe('Page Validations', () => {

    it('User Login Validations', () => {
        //cy.visit('https://www.instagram.com/sem/campaign/emailsignup/?campaign_id=13530338610&extra_1=s%7Cc%7C547419127631%7Ce%7Cinstagram%20%27%7C&placement=&creative=547419127631&keyword=instagram%20%27&partner_id=googlesem&extra_2=campaignid%3D13530338610%26adgroupid%3D126262414014%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-1321618851291%26loc_physical_ms%3D9198760%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gad_source=1&gclid=EAIaIQobChMI446EmoOfigMVyx-DAx0xRSVWEAAYASAAEgI_X_D_BwE')
        // cy.visit('https://auth0.com/blog/cypress-write-automated-tests-to-validate-web-applications/')
        // cy.scrollTo(0,14500);
        // cy.get('input[type="text"]').eq(3).type('tetsing.cypress@gmail.com', {force: true});

        cy.visit('https://auth0.com/blog/cypress-write-automated-tests-to-validate-web-applications/');
        cy.scrollTo(0, 14500);
        cy.get('input[type="text"]').eq(3).should('be.visible').type('tetsing.cypress@gmail.com', { force: true });
    })
})