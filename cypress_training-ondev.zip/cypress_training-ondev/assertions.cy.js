describe('Assertions', () => {

    // we have two types of assertions 1) Implicit Assertions  2) Explicit Assertions 
    // Implicit Assertions are .and(), .should()
    // Explicit Assertions are assert(), expect()
    it('Using Assertions', () => {

        cy.visit('https://practicetestautomation.com/practice-test-login/')
        cy.get('#site-title').then((element) => {
            expect(element.text()).to.equal('')

            // to get the title of the page
            cy.title().should('eq', 'Test Login | Practice Test Automation')
            // we are checking the page heading with have.text 
            cy.get('#login > h2').should("have.text", 'Test login')
            // checking for not have text condition for the text
            cy.get('#login > h2').should("not.have.text", 'Testt login')
            // checking whether we have contain same heading or not with contain
            cy.get('#login > h2').should("contain", 'Test login')
            // checking whether the page heading is visible or not
            cy.get("#login > h2").should("be.visible")
            // we can use have.html to check the inner element of the html
            cy.get("#login > h2").should("have.html", 'Test login')
            // checking the heading with contains()
            cy.get("#login > h2").contains('Test login')

            //cy.get("#login > h2").expect("Test login").to.have.attr('Username')   
            // check the length of the text
            cy.get("#login > h2").should('have.length', 1)
            // check the value of the given text
            cy.get("#login > h2").should('have.value', '')
            // to checking the element is not exists in the DOM
            cy.get("#login > h22").should('not.exist')
            // to check the label conatin the same name or not
            cy.get("label[for='username']").should('include.text', 'Username')
            // using regexpattern to check the assertion 
            const regexPattern = /^Home$/;
            cy.get('#menu-item-43').invoke('text').should('match', regexPattern)

            // to check the length of the text
            cy.get('#menu-item-43').should('have.length', '1')

            // to focus a particular element
            cy.get('input[type="text"]').focus();

            // checking the attribute is equal to the particular element
            cy.get('#password').scrollIntoView().should('have.attr', 'type', 'password')

            const result = 1 / 10;
            //wrap is used for non-Cypress objects
            cy.wrap(result).then(value => { expect(value).to.not.be.NaN })

            //checking the password filed should be empty or not
            cy.get('#password').should('be.empty').and('be.visible')

            // to check the checkbox is checked or not
            //cy.get('#myCheckbox').should('be.checked');

            // to check the radio button is checked or not 
            // cy.get('#myRadioButton').should('be.checked'); 

            // to verify if it is an array 
            const myArray = [1, 2, 3]
            cy.wrap(myArray).should(value => expect(value).to.be.an('array'))
            // checking specific element is present or not
            cy.wrap(myArray).should('not.include', 4)
            // to find the specified element is present in the tag or not
            cy.get('#site-footer').find('div')
        })
    })

})