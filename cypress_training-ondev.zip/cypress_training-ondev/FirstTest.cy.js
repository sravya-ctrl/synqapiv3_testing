describe('First Test', () => {

    it('First Test', () => {

        cy.visit("https://www.google.com/")
        cy.get('#APjFqb').type('Automation')
        
    })
})