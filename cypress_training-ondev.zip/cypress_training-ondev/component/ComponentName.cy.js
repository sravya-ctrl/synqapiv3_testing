// cypress/component/ComponentName.cy.js

import React from 'react';
import { mount } from 'cypress/react';  // Import mount from Cypress React
import ComponentName from '../../src/componentName'; // Adjust the path

describe('ComponentName.cy.js', () => {
  it('should render correctly with the given label', () => {
    // Mount the component with the label prop
    mount(<ComponentName label="Click me" />);
    
    // Assert that the button contains the text "Click me"
    cy.get('button').should('exist').click();  // Ensure button is present before clicking
  });

  it('should call onClick when button is clicked', () => {
    const onClick = cy.stub().as('onClick'); // Create a stub for onClick and alias it
    
    // Mount the component with the stubbed onClick function
    cy.mount(<ComponentName label="Click" onClick={onClick} />);
    
    // Click the button
    cy.get('button').click();
    
    // Assert that onClick was called exactly once
    cy.get('@onClick').should('have.been.calledOnce');
  });
  
});
