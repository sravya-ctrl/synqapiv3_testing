describe('Handling Frames',() => {

    it('Handling Frames using cypress', () => {
        
        cy.visit('http://13.232.29.116/hts-panel.html');
        cy.scrollTo(0,4500);
        cy.get('.video-iframe')
        .should('be.visible');
    })
})