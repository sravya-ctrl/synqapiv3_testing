describe('Reading data from Fixtures',() => {
    let userdata;
    before(() => {
        cy.fixture('loginData').then((data) => {
          userdata=data;
    })
})

    it('Data reading manually', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/login.html')
        
        cy.get('#username').type('Sravya')
        cy.get('#password').type('sravya@123')
        //cy.get('input[type="submit"]').click();
    })

    it('Data read from fixtures',() => {
    cy.fixture('loginData').then((data) => {
        cy.get('#username').type(data.username)
        cy.get('#password').type(data.password)
    })   
})

it('Fixture data for every tetscase', () => {
    cy.visit('http://127.0.0.1:5500/cypress/e2e/login.html')
    cy.get('#username').type(userdata.username)
    cy.get('#password').type(userdata.password)
})


})