describe('Functionality check', () => {

        it('Basic commands with example page', () => {
            
            cy.visit('https://testpages.eviltester.com/styled/reference/input.html');
            

        })
})


