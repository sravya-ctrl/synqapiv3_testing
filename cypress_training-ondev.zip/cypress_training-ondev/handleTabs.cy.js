describe('Handling Tabs', () => {

    it('Handling child tab within the same tab', () => {
        cy.visit('https://trains.abhibus.com/?channel=abhibus-web');  // Visit the main page

        // Directly set the URL via the window object if the JS does this in the background
        //cy.window() will access to the window object of the browser running the test 
        cy.window().then((win) => {
           // then method allows you to execute a function after obtaining the window object
          // Simulate a URL change if that's how the page is navigated
          win.location.href = 'https://www.ecatering.irctc.co.in/';  // Force the page to navigate in the same tab
        });
        
        // Verify the page's new content
        cy.url().should('include', 'ecatering');
        //cy.get('h1').should('contain', 'IRCTC FOOD BOOKING');
        
        

    })
})