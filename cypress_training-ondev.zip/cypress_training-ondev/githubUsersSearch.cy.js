describe('Github users search', () => {
    it('Github account user search', () => {
        cy.visit('https://ultimateqa.com/dummy-automation-websites/');
        scrollTo(0,5000);
        cy.get('#post-9600 > div.entry-content > ol > li:nth-child(5) > strong > a').should('be.visible').click();
        //then((link) => 
        //     {
        //         const url = link.prop('href');
        //         cy.visit(url);
        //     })
        //    cy.wait(3000);
    })

    it('Search the user', () => {
        cy.visit('https://gh-users-search.netlify.app/');
        cy.get('input[data-testid = "search-bar"]').type('Atforte');
        cy.get('button[type = "submit"]').click();
    })
})