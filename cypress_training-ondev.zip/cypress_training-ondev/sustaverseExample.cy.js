
function clickMenuAndLink(index) {
    cy.get('.menu-img').click();
    cy.get('.link-title1.title').eq(index).click();
}

function visitPage(url){
    cy.visit(url);
    cy.wait(5000);
}
    
describe('ExampleBasics', ()=> {
    it('example', ()=> {
    visitPage('http://13.232.29.116/');
       
        // clickMenuAndLink(0);
        // clickMenuAndLink(1);
        // clickMenuAndLink(2);
        [0,1,2].forEach(index => clickMenuAndLink(index)); 
        cy.get('.products').eq(5).trigger('mouseover').click();
        cy.get('.colored-image').click();
        cy.scrollTo(500,0);
        [3,4].forEach(index => clickMenuAndLink(index));
        // clickMenuAndLink(3);
        // clickMenuAndLink(4);
        

        // cy.get('.menu-img').click();
        // cy.get('.link-title1.title').eq(0).click();
        // cy.get('.menu-img').click();
        // cy.get('.link-title1.title').eq(1).click();
        // cy.get('.menu-img').click();
        // cy.get('.link-title1.title').eq(2).click();
        // cy.get('.products').eq(5).trigger('mouseover').click();
        // cy.get('.colored-image').click();
        // cy.scrollTo(500,0);
        //cy.get('.menu-img').click();
        // cy.get('.link-title1.title').eq(3).click();
        // cy.get('.menu-img').click();
        // cy.get('.link-title1.title').eq(4).click();
        // cy.get('.menu-img').click();
        // cy.get('.link-title1.title').eq(5).click();
        cy.get('.menu-img').click();
        cy.get('.link.contact2').click();
        cy.scrollTo(0,200);
  // cy.get('div.desk-dev').invoke('show');  // Force the div to be visible
  cy.get('#name', { multiple: true }).eq(0).click().type('123456'); // Type into the input field
  cy.get('.menu-img').click();
  cy.get('.solution-content').eq(0).click();
  cy.title().should('be.eq', 'AES');
  cy.get('#refinery-link').click();
  cy.get('#industrial-link').click();
  cy.get('.mbl-btn').click();
  cy.get('#services').click();
  cy.get('div>div>div>img').eq(3).click();
  cy.get('.menu-img').click();
  cy.get('.solution-content').eq(2).click();
  cy.title().should('be.eq', 'ITS');
  cy.get('#backButton').click();
  cy.get('.menu-img').click();
    });
});
