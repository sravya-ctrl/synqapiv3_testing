const { kMaxLength } = require("buffer");

function visitingThePage() {
    cy.visit('https://www.google.com/');   // open to goole page
    cy.get('#APjFqb').type('redbus');      // type redbus on the search bar
    cy.get('#jZ2SBf > div.wM6W7d > span').click();  // click on the first redbus from the autosuggestion
    cy.get('#rso > div.hlcw0c > div > div > div > div > div > div > div > div.yuRUbf > div > span > a > h3').click();  // click on the first link of the redbus 
    cy.get('#homeV2-root > div.topSection > h1').should('have.text',"India's No. 1 Online Bus Ticket Booking Site");   // checking the title of the page  //
}

function enterSourceLocation(source) {      // enter the source location
    cy.get('#src').type(source);            
    cy.get('.placeHolderMainText').eq(0).should('have.text', source).click();
}

function enterDestinationLocation(destination) {    // enter the destination location
    cy.get('#dest').type(destination);
    cy.get('.placeHolderMainText').eq(1).should('have.text', destination).click();
}

function selectFutureDate(daysFromToday) {         
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + daysFromToday);

    const futureDay = futureDate.getDate();
    const futureMonth = futureDate.getMonth() + 1;
    const futureYear = futureDate.getFullYear();

    cy.get('#onwardCal').then(() => {
        cy.get('#onwardCal').contains(futureDay).click();
    });
}
function searchBuses() {     
    cy.get('#search_button').click();
}

function invalidSearch() {
    searchBuses();
    cy.get('#autoSuggestContainer > div > div > div:nth-child(1) > div > div.sc-jTzLTM.bIZuun').should('contain','Enter');
}

function swapArrowClick() {
    cy.get('#autoSuggestContainer > div > div > div.sc-eHgmQL.ehQshY > i').click();
}

function lookingTrendingOffers() {
    cy.scrollTo(0,300);
    // Prevent the link from opening in a new tab
   cy.get('#homeV2-root > div.sc-bRBYWo.inExtF > div > div > div.OfferSection__OfferHeadSection-sc-16xojcc-2.bBoDuC > a').invoke('removeAttr', 'target').click();
    cy.get('#mBWrapper > table > tbody > tr:nth-child(1) > td:nth-child(1)').click();
    cy.get('.icon-close').click();
    cy.scrollTo(0,500);
    cy.get('#mBWrapper > table > tbody > tr:nth-child(3) > td:nth-child(2)').trigger('mouseover').should('contain','Use Code SBNEW');
    //cy.scrollTo(0,400);
}

function webIconArrow() {
    visitingThePage();
    cy.scrollTo(0,200);
    cy.get('#offerCarousel > span > span > i').click();
    //cy.get('#offerCarousel > span > span > i').click();
}

function lookingForGovernmentBuses() {
    cy.scrollTo(0,300);
    cy.get('#homeV2-root > div.rtcSection > div.rtcHeadViewAll > div:nth-child(2) > a').invoke('removeAttr', 'target').click();
    cy.get('#root > div > article:nth-child(4) > div > div > ul:nth-child(1) > li:nth-child(5) > a').should('contain','AP').click();
}

function selectingBusticketsForAPSRTC() {
    const futureDate = new Date();
    // Using Lodash's random function to generate a random 4-digit number
    const random4DigitNumber = Cypress._.random(1000, 9999); // Generates a number between 1000 and 9999
    cy.get('#txtSource').type(random4DigitNumber).first().click();
    const random3DigitNumber = Cypress._.random(100, 999); 
    cy.get('#txtDestination').type(random3DigitNumber).first().click();
    //searchBuses();
}

function bookTrainTicketsByClickingRadioButtons() {
        cy.get('#rail_tickets_vertical').click();
        //visibility of the radio buttons
       cy.get('#root > section > div.banner > div.new_srp_widget_overlay > div.ris-wrapper > div:nth-child(2) > div').should('be.visible').click();
       cy.get('#root > div > section > div.banner > div.ris-wrapper > div:nth-child(1) > div').should('be.visible').click();
       
        // selecting radio buttons with another approach - with check() we have input type = radio 
        // cy.get('#root > section > div.banner > div.new_srp_widget_overlay > div.ris-wrapper > div:nth-child(2) > div').check().should('be.checked');
        //  cy.get('#root > div > section > div.banner > div.ris-wrapper > div:nth-child(1) > div > div').should('not.be.checked');
    }

function freeCancellationByClickingCheckbox() {
    // selecting checkbox
     cy.get('#root > section > div.banner > div.new_srp_widget_overlay > div.search-widget-wrapper > div > form > div.fc_optin_main_wrap_home > div.checkbox_wrap').should('be.visible').click();
    // unselect the checkbox
     cy.get('#root > section > div.banner > div.new_srp_widget_overlay > div.search-widget-wrapper > div > form > div.fc_optin_main_wrap_home > div.checkbox_wrap_pass.red_background')   // Select the checkbox div
  .click()                  // Click to toggle the checkbox state
  .should('not.have.class', 'checked'); // Verify the checkbox is unchecked (no 'checked' class)

       // cy.get('.checkbox_wrap').should('be.visible').click();
      //  cy.get('.checkbox_wrap').should('be.visible').click();
    }    

    function selectingDropdownElement() {
        cy.get('#result-section > div.group-data.clearfix > div > div.clearfix > div > div.w-14.fl > div.button').click();
        cy.scrollTo(0,800);
        cy.get("#\\33 0134776 > div > div.clearfix.m-top-16 > div.button.view-seats.fr").should('have.text','View Seats');     
    }

    function autoSuggestedDropdown() {
        cy.visit('https://www.redbus.in/railways/train-running-status?from=Home%20Dweb');
        //cy.get('')
    }

    // function checkingMyaccountFunctionality(){
    //     visitingThePage();
    //     cy.get('#account_dd').click();
    //     cy.get('#user_sign_in_sign_up').click();
    //     cy.get('#mobileNoInp').type('9505429648');

    //      // Intercept the POST request for CAPTCHA verification and mock it
    // cy.intercept('POST', '/api/captcha/validate', {
    //     statusCode: 200,
    //     body: {
    //       success: true, // Simulate a successful CAPTCHA validation
    //     },
    //   }).as('captchaValidation');

    //     cy.get('#profile_detail').invoke('removeAttr', 'target').click();
    //     cy.get('#Editbtn').click();
    //     cy.get('#profile-displayName').invoke('attr','maxlength').then((maxLength) => {
    //             cy.log('Max length is'+ maxLength);
    //     })
    // }


describe('Red Bus Page Testing', () => {

    beforeEach(function() {
        // Visit the Google page
        cy.visit('https://www.google.com/');   // open to goole page
        cy.get('#APjFqb').type('redbus');      // type redbus on the search bar
        cy.get('#jZ2SBf > div.wM6W7d > span').click();  // click on the first redbus from the autosuggestion
        
        // Wait for the body to load completely
        // it will get all the elements of the page
        cy.get('body', { timeout: 20000 }).then(($body) => {
          // Log the body content to check if the popup is there
          cy.log($body.text());
      
          // Check if the popup with the desired text exists
          // div:contains is checking for the text "See results closer to you?" of this element div tag
          if ($body.find('div:contains("See results closer to you?")').length > 0) {
            // Wait for the popup to be fully visible
            cy.get('div:contains("See results closer to you?")', { timeout: 20000 })
              .should('be.visible')
              .then(($popup) => {
                // If the popup is visible, find the "Not now" button and click it
                cy.wrap($popup)
                  .closest('div') // Get the closest parent of the popup
                  cy.wait(7000)
                   //.find('button')
                  .contains('Not now')
                  .click();
              });
          } else {
            // If the popup does not appear, log a message
            cy.log('Popup did not appear or has a different structure.');
          }
        });      
    //cy.get('#rso > div.hlcw0c > div > div > div > div > div > div > div > div.yuRUbf > div > span > a > h3').click(); 
          })

    it('Visiting the page', () => {
        visitingThePage();
    })
    it('should select source and destination cities', () => {
         visitingThePage();
        enterSourceLocation('Hyderabad');
        enterDestinationLocation('Bangalore');
    })
    it('should select a date in the future', () => {
        visitingThePage();
        enterSourceLocation('Hyderabad');
        enterDestinationLocation('Bangalore');
        selectFutureDate(2);
        searchBuses();
        selectingDropdownElement();
    })
    it('Invalid Search criteria', () => {
        visitingThePage();
        invalidSearch();
    })
    it('Action click on swaparrow', () => {
        visitingThePage();
        enterSourceLocation('Hyderabad');
        enterDestinationLocation('Bangalore');
        swapArrowClick();
    })
    it('Looking for trending offers', () => {
       visitingThePage();
       lookingTrendingOffers(); 
    })
    it('Looking for Government Buses', () => {
        visitingThePage();
        lookingForGovernmentBuses();
        selectingBusticketsForAPSRTC();
    })
    it('Book a train ticket', () => {
        visitingThePage();
        bookTrainTicketsByClickingRadioButtons();
        freeCancellationByClickingCheckbox();
    })
    // it('checking Myaccount details',() => {
    //     checkingMyaccountFunctionality();
    // })

    
})
