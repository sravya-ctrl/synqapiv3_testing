import 'cypress-file-upload';

describe('Uploading File',() => {

    it('Single file upload', () => {
        cy.visit('https://practice.expandtesting.com/upload');
        cy.get('#fileInput').attachFile('Rohith Resume 2024.pdf')
        cy.get('#fileSubmit').click();
        cy.get('body > main > div.page-layout > div > h1').should('have.text','File Uploaded!');
    })

    it('File Upload and rename', () => {
        cy.visit('https://practice.expandtesting.com/upload');
        cy.get('#fileInput').attachFile({filePath:'Rohith Resume 2024.pdf', fileName:'Resume.pdf'});
        cy.get('#fileSubmit').click();
        cy.wait(5000);
        cy.get('body > main > div.page-layout > div > h1').should('have.text','File Uploaded!');
    })

    it('File upload - Drag and Drop', () => {
        cy.visit('https://www.w3schools.com/html/html5_draganddrop.asp');
        cy.get('#div2').eq(1).attachFile('img_w3slogo',{subjectType: 'drag-n-drop'});
        cy.wait(5000);
        cy.get('#drag1').eq(1).contains('img_w3slogo');
    })

    it('Multiple files upload', () => {
        cy.visit('https://www.patternfly.org/components/file-upload/multiple-file-upload/');
        
        // Wait for the page to load completely
        cy.wait(2000); 
        
        // Scroll to the correct element or use the window
        cy.get('.pf-v6-c-multiple-file-upload__upload').scrollIntoView();  // Scrolling to an element
        
        // If you really need to scroll the window
        cy.scrollTo(0, 1000, { ensureScrollable: false });  // Scroll window
        cy.get('#ws-react-c-multiple-file-upload-basic > div.pf-v6-c-multiple-file-upload > div.pf-v6-c-multiple-file-upload__main > div.pf-v6-c-multiple-file-upload__upload > button')
            .attachFile(['deliveryChallan.pdf', 'package-FBA15JK1LB7K.pdf']);
        
        cy.wait(5000);
        cy.get('#pf-expandable-section-2-toggle > span.pf-v6-c-button__text > div > div.pf-v6-c-multiple-file-upload__status-progress-text')
            .should('contain.text', 'files uploaded');
    });

    it.only('file upload - Shadow dom', () => {
        cy.visit('https://practice.expandtesting.com/shadowdom')
        cy.get('#my-btn',{includeShadowDom:true}).attachFile('deliveryChallan.pdf');
    })
})