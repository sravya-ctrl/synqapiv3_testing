    //before
    //after
    //beforeEach
    //afterEach

describe('HooksAndTags', ()=> {
    
    before(()=> {

    cy.log(" === Launch APP ===")
    })

    after(() => {
        cy.log(" === Close App ===")
    })

    beforeEach(() => {
      cy.log(" === Login ===")
    })

    afterEach(() => {
            cy.log("=== Logout ===")
    })

    it('search',() => {

        cy.log(" ==== Searching ====")
    })

    it.skip('advanced search', () => {

        cy.log(" === Advanced Searching ====")
    })

    it('listing the products', () => {

        cy.log(" === Listening Products ===")
    })



})