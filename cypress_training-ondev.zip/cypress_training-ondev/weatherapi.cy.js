describe('check weather information',() => {

    it('get weather information for cities', () => {
            // Get all locations based on search criteria
        cy.request({
            method : 'GET',
            url: 'https://publicapi.dev/weather-api/?query=San'
        }).then((response)=> {
           const city = response.body[0].title
            return city;
        })
        .then((city) => {
            // from all the list of locations select the first data
            cy.request({
                method: 'GET',
                url: 'https://publicapi.dev/weather-api/?query='+ city
            }).then((response)=> {
                expect(response.status).to.eq(200)
                expect(response.body[0].to.have.property('title', city))
            })
        })
    })

// =======================================================================

    it('get weather information for all cities', () => {
        // Get all locations based on search criteria
    cy.request({
        method : 'GET',
        url: 'https://publicapi.dev/weather-api/?query=Am'
    }).then((response)=> {
       const location = response.body
        return location;
    })
    .then((location) => {

        for(let i=0; i<location.length;i++) {
        // from all the list of locations select the first data
        cy.request({
            method: 'GET',
            url: 'https://publicapi.dev/weather-api/?query='+ location[i].title
        }).then((response)=> {
            expect(response.status).to.eq(200)
            expect(response.body[0].to.have.property('title', location[i].title))
        })
    }
    })
})
// ================================================================================

it('POSt and PUT call',() => {

    cy.request({
        method: 'POST',
        url:'',
        body : {
            name: "Test Automation cypress",
            gender:"female",
            email: "sravyatestcypress@gmail.com",
            status: "active"
        }
    }).then((response) => {
        expect(response.status).to.eq(201)
        expect(response.body.data).has.property('email','sravyatestcypress@gmail.com')
        expect(response.body.data).has.property('name','Test Automation cypress')
        expect(response.body.data).has.property('status','active')
    }).then((response) => {
        const userId = response.body.data.id
        cy.request({
            method: 'PUT',
            url: '',
            headers: {
                'Authorization': ''
            }, 
            body: {
            name: "Test Automation cypress updated",
            gender:"female",
            email: "sravyatestcypressupdated@gmail.com",
            status: "inactive"
            }
        }).then((response) => {
            expect(response.status).to.eq(200)
            expect(response.body.data).has.property('email','sravyatestcypressupdated@gmail.com')
            expect(response.body.data).has.property('name','Test Automation cypress updated')
            expect(response.body.data).has.property('status','inactive')
    })
    })
})
})
