describe('Sample Registration Form testing page', () => {

    it('Registering user successfully', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya').should('have.value', 'Sravya');
        cy.get('#last-name').type('Salina').should('have.value', 'Salina');
        cy.get('#email').type('test123@gmail.com').should('have.value', 'test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#phone').should('have.value', '9234567876');  // Assert phone number is entered correctly
        const futureDay = '2024-12-18';
        cy.get('#dob').type(futureDay);
        cy.get('#dob').should('have.value', '2024-12-18');  // Assert the correct date is entered        
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#newsletter').should('be.checked');  // Assert that the newsletter checkbox is checked
        cy.get('#terms').click();
        cy.get('#terms').should('be.checked');  // Assert that the terms checkbox is checked
        cy.get('#music').click();
        cy.get('#music').should('be.checked');  // Assert that 'music' checkbox is checked
        cy.get('#tech').click();
        cy.get('#tech').should('be.checked');  // Assert that 'tech' checkbox is checked
        cy.get('#sports').click();
        cy.get('#sports').should('be.checked');  // Assert that 'sports' checkbox is checked
        cy.get('#country').select(1);
        cy.get('#country').should('have.value', 'usa');  // Assert that the value of the country is 'United States' (assuming index 1 corresponds to United States)
        cy.get('#message').type('This is testing page for sample');
        cy.get('#message').should('have.value', 'This is testing page for sample');  // Assert message is entered correctly
        cy.get('#password').type('r54t6y7u');
        cy.get('#password').should('have.value', 'r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#confirm-password').should('have.value', 'r54t6y7u');
        cy.get('#registrationForm > button').should('be.visible').click();
        cy.get('#successAlert').should('be.visible').and('contain.text', 'Registration successful! Thank you for signing up.');  // Replace with your actual success message element and text
    })

    it('should not accept more than 10 characters for name', () => {

        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        // Type a name longer than 10 characters
        cy.get('#first-name').type('ThisNameIsWayTooLong');

        // Assert that the value is still limited to 10 characters (if there’s a max length constraint)
        cy.get('#first-name').should('have.value', 'ThisNameIs');  // assuming it truncates after 10 chars

        cy.get('#last-name').type('ThisLastNameIsWayTooLong');
        cy.get('#last-name').should('have.value', 'ThisLastNa');

        cy.get('#email').type('1234567345').blur();

        cy.get('#phone').type('qwertyuiop');
        cy.get('#registrationForm > button').should('be.visible').click();
    });

    it('Should show error for firstname with special characters and digits', () => {
        // Visit the registration page
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Enter a firstname with special characters and digits
        cy.get('#first-name').type('sravya123!@#');  // Invalid first with digits and special characters

        // Enter other required fields
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is a test message');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');

        // Click the submit button
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for missing first name', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for missing last name', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for invalid email format', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('23456trhjhui');  // Invalid email
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for invalid phone number', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('923AB67876');  // Invalid phone number
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for future date of birth', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2024-12-18');  // Invalid future date
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for mismatched passwords', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('werty345');  // Mismatched password
        cy.get('#registrationForm > button').click();

        // Assert that the password mismatch error message is displayed
        cy.get('#registrationForm > div.error').should('be.visible').and('contain.text', 'Passwords do not match');
    });

    it('Should show error for not accepting terms and conditions', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        // Do not check the terms box
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for missing required fields', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Do not type anything in required fields
        cy.get('#first-name').clear();
        cy.get('#last-name').clear();
        cy.get('#email').clear();

        cy.get('#registrationForm > button').click();
    });

    it('Should show error for already registered email', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('existingemail@gmail.com');  // Email already registered
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for short phone number', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('923');  // Short phone number (error : Please match the requested format)
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for invalid country selection', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select('aus');  // Invalid country   // it will fail here as country don't have aus option
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for empty password field', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#confirm-password').type('r54t6y7u');  // Empty password field  // required field for registration
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for short password', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('123');  // Password too short
        cy.get('#confirm-password').type('123');
        cy.get('#registrationForm > button').click();
    });

    it('Should show error for missing gender selection', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#message').type('This is testing page for sample');
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');
        cy.get('#registrationForm > button').click();
    });

    it('should not accept more than 10 characters for first name and last name', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#'); // Replace with your registration page URL

        // Test case for first name (more than 10 characters)
        cy.get('#first-name').type('SravyaSalina');  // 12 characters
        cy.get('#first-name').should('have.value', 'SravyaSali'); // Only first 10 characters should be accepted

        // Test case for last name (more than 10 characters)
        cy.get('#last-name').type('SalinaSalina');  // 12 characters
        cy.get('#last-name').should('have.value', 'SalinaSali'); // Only first 10 characters should be accepted

        // Fix the error by typing 10 characters or less
        cy.get('#first-name').clear().type('Sravya'); // Valid name within limit
        cy.get('#last-name').clear().type('Salina'); // Valid name within limit
    });

    it('Should navigate to the login page when "Login" link is clicked', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Force the click in case the element is not interactable
        cy.get('#registrationForm > div > p > a').click({ force: true });

        // Assert the URL to check if it redirects correctly
        cy.url().should('include', 'registrationLogin.html');

        // for the login form   
        // Enter valid username
        cy.get('#login-username').type('firstuser');

        // Enter valid password
        cy.get('#login-password').type('userpassword123');

        // Click the login button
        cy.get('#loginForm > button').click();

    });

    it('should select the checkboxes for Tech, Music, and Sports', () => {
        // Visit the registration page
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Select the checkbox for Tech interest
        cy.get('#tech').check().should('be.checked');

        // Select the checkbox for Music interest
        cy.get('#music').check().should('be.checked');

        // Select the checkbox for Sports interest
        cy.get('#sports').check().should('be.checked');


        // Optionally: Assert if the checkboxes are selected
        cy.get('#tech').should('be.checked');
        cy.get('#music').should('be.checked');
        cy.get('#sports').should('be.checked');
    });

    it('should unselect the checkboxes for Tech, Music, and Sports', () => {
        // Visit the registration page
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Ensure the checkboxes are selected first (for testing the unselect action)
        cy.get('#tech').check();
        cy.get('#music').check();
        cy.get('#sports').check();

        // Unselect the checkbox for Tech interest
        cy.get('#tech').uncheck().should('not.be.checked');

        // Unselect the checkbox for Music interest
        cy.get('#music').uncheck().should('not.be.checked');

        // Unselect the checkbox for Sports interest
        cy.get('#sports').uncheck().should('not.be.checked');

        // Optionally: Assert if all checkboxes are unselected
        cy.get('#tech').should('not.be.checked');
        cy.get('#music').should('not.be.checked');
        cy.get('#sports').should('not.be.checked');
    });

    it('Should allow entering exactly 256 characters in the Additional Information field', () => {
        // Visit the registration page
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Enter valid data for other fields
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');

        // Enter exactly 256 characters in the Additional Information field
        cy.get('#message').type('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.');

        // Click the submit button
        cy.get('#registrationForm > button').click();
    });

    it('Should show an error for entering more than 256 characters in the Additional Information field', () => {
        // Visit the registration page
        cy.visit('http://127.0.0.1:5500/cypress/e2e/registrationLogin.html#');

        // Enter valid data for other fields
        cy.get('#first-name').type('Sravya');
        cy.get('#last-name').type('Salina');
        cy.get('#email').type('test123@gmail.com');
        cy.get('#phone').type('9234567876');
        cy.get('#dob').type('2000-12-18');
        cy.get('#female').click();
        cy.get('#newsletter').click();
        cy.get('#terms').click();
        cy.get('#country').select(1);
        cy.get('#password').type('r54t6y7u');
        cy.get('#confirm-password').type('r54t6y7u');

        // Enter more than 256 characters in the Additional Information field
        cy.get('#message').type('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.'); // More than 256 characters

        // Click the submit button
        cy.get('#registrationForm > button').click();
    });

});








