describe("dummy data", () => {
it.only('should show popup when Accept All is clicked', () => {
    cy.visit('https://www.sap.com/germany/index.html', {
        failOnStatusCode: false
    }).then((response) => {
        // Handle the response as needed
        if (response.status === 403) {
            cy.log('Access Denied: 403 Forbidden');
            cy.wait(2000);
            // You can add further handling logic here
        } else {
             // Close the popup
  // cy.contains('Accept All').click();
            // Proceed with your tests
        }
    });

    Cypress.on('uncaught:exception', (err, runnable) => {
        // Prevent Cypress from failing the test
        return false;
      });
    });

});