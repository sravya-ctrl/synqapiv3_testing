describe('Capture Screen shots and videos on failures',() => {

    it('Capture Screen shots and videos', () => {
        cy.visit('https://www.patternfly.org/components/file-upload/multiple-file-upload/react-demos/')
        cy.screenshot('hithub');

        // Automatically capture screenshot & video on failure - only on headless mode 
        // we have to run cypress in headless mode then we can see the failure screenshots and videos in the screen shots and videos folder
         
    })
})