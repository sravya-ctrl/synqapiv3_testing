describe('Dropdown Handling', () => {

    it.skip('selecting a value from dropdown', () => {
        cy.visit('https://webdriveruniversity.com/Dropdown-Checkboxes-RadioButtons/index.html')
        cy.get('#dropdowm-menu-1').select('python').should('have.value','python');
    })

    it('Invalid username', () => {
        cy.visit('https://parabank.parasoft.com/parabank/index.htm');
        // cy.get('input[type="text"]').type('23423');
        //cy.get('input[type="text"]').type('sravya@123');
        //cy.get('input[type="text"]').type('S23@getMaxListeners.com');
        //cy.get('input[type="text"]').type('_');
        //cy.get('input[type="text"]').type(" ");
        //cy.get('input[type="text"]').type('srtyuiopkjhgfdsxcvbnmbvcsrtyh');
        //cy.get('input[type="text"]').type('sravya');
        cy.get('input[type="text"]').type('test!@#$%^&*').should('have.value', 'test!@#$%^&*');

        cy.get('input[type="password"]').type('12345678');
        cy.get('input[type="submit"]').click();
        cy.get('#loginPanel > p:nth-child(2) > a').click();
        cy.get('#rightPanel > p').should('have.text','Please fill out the following information in order to validate your account.');
        //cy.get('#rightPanel > p').should('have.text','The username and password could not be verified.');
        //cy.get('#rightPanel > p').should('have.text','Please enter a username and password.');
    })

        it.only('should get the maxlength of the input field', () => {
          // Visit the page where the input field is located
          cy.visit('https://parabank.parasoft.com/parabank/index.htm');
          cy.get('#loginPanel > p:nth-child(2) > a').click();
          let characters = ' ';
          const charactersLength = characters.length;
          let char = characters.charAt(Math.floor(Math.random() * charactersLength));
          //const randomCharacters = Cypress._.random(char); 
              // Define the string of 256 characters (you can use any string of your choice)
              const longString = char.repeat(256); // Creates a string of 256 'A' characters
          
              // Find the First Name input field, type the long string, and verify the value
              cy.get('input[name="firstName"]')  // Use the correct selector for the first name field
                .type(longString)                // Type the 256 characters into the input field
                .should('have.value', longString) // Verify that the input field contains the 256 characters
                .should('have.attr', 'maxlength', '256'); // Verify that the maxlength attribute is 256
            });
          });
      