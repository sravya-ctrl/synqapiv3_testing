describe('Customized API testing', () => {
    it('API Method call Testing by ID', () => {
      cy.request({
        method: 'DELETE', // Use GET to retrieve the data
        url: 'http://localhost:3000/login/0d23', // 
        // body: {
        //     username: 'Admin',
        //     password: 'Admin@123',
        //     status: 'Success',
        //     message: 'Login SUccessfull',
        //     login: 'active'
        // }, 
        failOnStatusCode: false, // Prevent test failure on non-2xx status codes
      }).then((response) => {
        // Verify the response
        expect(response.status).to.eq(200); // Verify the status code is 200
        // expect(response.body).to.have.property('username', 'Admin'); // Check the username
        // expect(response.body).to.have.property('password', 'Admin@123'); // Check the password
        // expect(response.body).to.have.property('status','Success');
        // expect(response.body).to.have.property('message','Login SUccessfull')
        // expect(response.body).to.have.property('id', '6fef'); // Check the ID is correct
      });
    });
  });
  