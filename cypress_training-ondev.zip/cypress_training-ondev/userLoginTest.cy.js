import LoginPage2 from '../PageObjects/LoginPage2.js';

describe('User Login Test page', () => {

    // Manually giving values to the user login
    it('User Login', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/userLogin.html')
        cy.get('#username').type('Sravya')
        cy.get('#password').type('Test123')
        cy.get('button[type="submit"]').click();
        cy.get('#successMessage').should('have.text', 'Login successful!')
    })

    // By importing page class we are using login 
    it('Login Test', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/userLogin.html')

        // Instantiate LoginPage class
        const obj = new LoginPage2();
        obj.setUserName('Sravya');
        obj.setPassword('Pswd');
        obj.clickSubmit();
        obj.verifyLogin();
    })


    // reading data from fixtures 
    it.only('Login Test', () => {
        cy.visit('http://127.0.0.1:5500/cypress/e2e/userLogin.html')

        cy.fixture('loginData').then((data) => {
        // Instantiate LoginPage class
        const obj = new LoginPage2();
        obj.setUserName(data.username);
        obj.setPassword(data.password);
        obj.clickSubmit();
        obj.verifyLogin();

        })

    })

})
