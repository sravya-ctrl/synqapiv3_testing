 // Before
 // After
 // BeforeEach
 // AfterEach


describe('Hooks And Tags', () => {

    // for each it() block this will execute first only once 
    before( () => {
        cy.log('Before');
    })
    // after execution of all it() it will execute only once
    after( () => {
        cy.log('After');
    })

  // for each it() block it will execute first  
    beforeEach( ()=> {
        cy.log('BeforeEach')
    })
  //  after execute all the it() blocks then it will execute 
    afterEach( () => {
        cy.log('AfterEach');
    })

    it('Seaching', () => {
        cy.log('Basic Search')
    })

    // tags are .only and .skip
    it.only('Advanced Search', () => {
        cy.log('Advanced Search')
    })
})