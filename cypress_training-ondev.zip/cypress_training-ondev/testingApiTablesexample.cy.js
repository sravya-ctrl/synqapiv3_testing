describe('API Testing using tables', () => {
    it('tables testing',() => {
        cy.request({
            method: 'GET',
            url: 'http://localhost:3000/users',
            failOnStatusCode: false,
        }).then((response) => {
            expect(response.status).to.eq(200)
            expect(response.body).to.be.an('array');
        })
    })
 
        it('Tables Testing (POST)', () => {
            cy.request({
                method: 'POST',
                url: 'http://localhost:3000/users', // Correct endpoint for creating a user
                body: {
                    name: 'atforte',
                    email: 'atforte@example.com'
                },
                failOnStatusCode: false,  // Don't let Cypress fail immediately on non-2xx status codes
            }).then((response) => {
                // Assert the status code is 201 (Created)
                expect(response.status).to.eq(201);
    
                // Check that the response body contains the new resource
                expect(response.body).to.have.property('id');
                expect(response.body).to.have.property('name', 'atforte');
                expect(response.body).to.have.property('email', 'atforte@example.com');
            });
        });

        it('Tables Testing (PUT)', () => {
            cy.request({
                method: 'PUT',
                url: 'http://localhost:3000/users/0ab4', // Correct endpoint for creating a user
                body: {
                    name: 'atforte Consultancy Service',
                    email: 'atforteconsultancy@example.com',
                    age: 26,
                    city: 'Hyderabad'
                },
                failOnStatusCode: false,  // Don't let Cypress fail immediately on non-2xx status codes
            }).then((response) => {
                // Assert the status code is 201 (Created)
                expect(response.status).to.eq(200);
    
                // Check that the response body contains the new resource
                expect(response.body).to.have.property('id', '0ab4');
                expect(response.body).to.have.property('name', 'atforte Consultancy Service');
                expect(response.body).to.have.property('email', 'atforteconsultancy@example.com');
                expect(response.body).to.have.property('age', 26);
                expect(response.body).to.have.property('city', 'Hyderabad');
            });
        });

            it('Update user data (PATCH)', () => {
              cy.request({
                method: 'PATCH',
                url: 'http://localhost:3000/users/0ab4',  // Correct endpoint for the user with id = 4
                body: {
                  age: 28   // Updated age
                },
                failOnStatusCode: false,  // Prevent Cypress from failing on non-2xx status codes
              }).then((response) => {
                // Assert the status code is 200 (OK)
                expect(response.status).to.eq(200);
          
                // Check that the response body contains the updated data
                expect(response.body).to.have.property('id', '0ab4');  // Check id
                expect(response.body).to.have.property('age', 28);  // Check updated age
              });
            });


            it('Delete user data (DELETE)', () => {
                cy.request({
                  method: 'DELETE',
                  url: 'http://localhost:3000/users/9317',  // Replace with the id of the user you want to delete
                  failOnStatusCode: false,  // Prevent Cypress from failing on non-2xx status codes
                }).then((response) => {
                  // Assert that the status code is 200 (OK)
                  expect(response.status).to.eq(200);
        });
    })

 // =========================================================================================  

    it('FIltering the Name and validate', () => {
        cy.request({
            method : 'GET',
            url: 'http://localhost:3000/users',
            failOnStatusCode: false,
        }).then((response) => {
            expect(response.status).to.eq(200)
            expect(response.body).to.be.an('array')

            const filteredUser = response.body.filter(user => user.name === 'automation');
            
            // it will filter the data and return only one
            expect(filteredUser).to.have.lengthOf(1);
           // expect(filteredUser).to.be.greaterThan(0);
            // it will check the first and only user in the list have name 'automation'
            expect(filteredUser[0]).to.have.property('name','automation');
        })
    })

 // ==========================================================================
 
   it('Negative API testing 404 Invalid endpoint', () => {
      cy.request({
        method: 'GET',
        url: 'http://localhost:3000/users/Invalid-endpoint',
        failOnStatusCode: false,
      }).then((response) => {
        expect(response.status).to.eq(404); // true 
      })
   })

   it('400 for missing required parameters', () => {
    // if we try to work with login page, the mandatory fields are missed 
        cy.request({
            method: 'POST',
            url: 'http://localhost:3000/users/Login',
            body: {
                username: 'user'
            },
            failOnStatusCode: false,
        }).then((response)=> {
            expect(response.status).to.eq(400);     
            expect(response.body).to.have.property('error', 'Missing password')
        })
   })

   it('400 for Invalid data type', () => {
    cy.request({
        method : 'POST',
        url: 'http://localhost:3000/users',
        body: {
            name: 'New User'
        },
        failOnStatusCode: false,
    }).then((response) => {
        expect(response.status).to.eq(400)
        expect(response.body).to.have.property("error', 'Invalid data type for")
    })
   })

it('Empty or missing required fields', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users',
        body: {
            username: '',
            email: '',
            error: 'Empty or missing required fields'
        }
    }).then((response) => {
      expect(response.status).to.eq(201);
      expect(response.body).to.have.property('error','Empty or missing required fields')
    })
})

it('Invalid field values - Exceeding character limits', () => {
        cy.request({
            method: 'POST',
            url: 'http://localhost:3000/users',
            body: {
                username: 'ThisIsAnIncrediblyLongUsernameThatExceedsTheCharacterLimit',
                error: 'This Is An Incredibly Long Username That Exceeds The Character Limit'
            }
        }).then((response) => {
            expect(response.status).to.eq(201);
            expect(response.body).to.have.property('error','This Is An Incredibly Long Username That Exceeds The Character Limit')
        })
})
 
 it('Invalid field values - malformed data', () => {
        cy.request({
            method: 'POST',
            url: 'http://localhost:3000/users',
            body: {
                email: '21345asdrtyg@gmail.com',
                error: 'Invalid Email'
            }
        }).then((response) => {
            expect(response.status).to.eq(201);
            expect(response.body).to.have.property('error','Invalid Email')
        })
})

it('Extra or irrelevant keys in the payload', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users',
        body: {
            username: 'Sravya',
            extra_key: 'No value',
            error: 'Irrelevant value'
        }
    }).then((response) => {
       expect(response.status).to.eq(201)
       expect(response.body).to.have.property('error','Irrelevant value')
    })
})

it('Incorrect or invalid HTTP methods', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users/70a4',
        failOnStatusCode: false
    }).then((response) => {
        expect(response.status).to.eq(404)
})
})

it('Invalid endpoint paths',() => {
    cy.request({
        method: 'GET',
        url: 'http://localhost:3000/users/70a',    // passing invalid id 
        failOnStatusCode: false
    }).then((response) => {
        expect(response.status).to.eq(404)
})
})

it('Query parameters instead of using the request body in POST requests', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users?username=testuser'   // by giving queryparameters
    }).then((response) => {
        expect(response.status).to.eq(201)
    })
})

it('Missing or Invalid authentication headers',() => {
    cy.request({
        method: 'GET',
        url: 'http://localhost:3000/users',
        headers: {
            'Authorization': 'Invalid API_KEY'
        },
        body: {
            error: 'Invalid api key'
        },
        failOnStatusCode: false
    }).then((response) => {
        expect(response.status).to.eq(200)
        expect(response.body).to.have.property('error', 'Invalid api key');
    })
})

// it('Incorrect data structure - array instead of an object', () => {
//     cy.request({
//         method: 'POST',
//         url: 'http://localhost:3000/users',
//         body: [
//             "username": "testuser",         //  (404) Bad request , Unexpected token, expected "," (258:22)
//             "email": "test@example.com"
//         ],
//     })
// })

it('Incorrect data structure - object instead of an array', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users',
        body: {
            users: {                          // 404 Bad request
                username: 'testusers',     
                email: 'test@example.com'
            }
        }
    }).then((response) => {
        expect(response.status).to.eq(201)
        expect(response.body[1]).to.have.property('username','testusers');
        expect(response.body[1]).to.have.property('email','test@example.com')
    })
})

it('JSON formatting issues - invalid Unicode characters', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users',
        body: {
            username: 'test\uFFFFFuser',            
        }
    }).then((response) => {
        expect(response.status).to.eq(201)
        expect(response.body).to.have.property('username','test\uFFFFFuser')
    })
})

it.only('Duplicate keys in the payload', () => {
    cy.request({
        method: 'POST',
        url: 'http://localhost:3000/users',
        body: {
            username: 'testuser',
            username: 'testuser'
        }
    }).then((response) => {
        expect(response.status).to.eq(201)
        expect(response.body).to.have.property('username','testuser')
    })
})



})
