require('@4tw/cypress-drag-drop')
describe('Mouse Events', () => {
    it('Mouse Over', () => {
        cy.visit('https://auth0.com/blog/cypress-write-automated-tests-to-validate-web-applications/');
        cy.get('#__next > header > nav.styled__NavMobile-sc-1755fzv-9.gZnwIf > div').click();
        cy.get('#__next > header > nav.styled__NavMobile-sc-1755fzv-9.gZnwIf > section > ul > li:nth-child(1)').click();
        cy.get('#__next > header > nav.styled__NavMobile-sc-1755fzv-9.gZnwIf > section > ul > li:nth-child(1) > div > div:nth-child(1) > ul > li:nth-child(1) > a').trigger('mouseover').click();
    })

    it('Right click', () => {
        cy.visit('https://www.softwaretestingmentor.com/automation-practice-page-right-click-demo/');
        // cy.get('#post-18170 > header > h1').trigger('contextmenu');
        // Temporarily show the context menu for testing purposes
        cy.get('#customContextMenu').invoke('css', 'display', 'block');

        // Now perform the right-click
        cy.get('#post-18170 > header > h1').rightclick();
        cy.get('#customContextMenu > ul > li:nth-child(3)').should('be.visible');
    })

    it('Double click', () => {
        // Visit the page containing the iframe
        cy.visit('https://www.w3schools.com/Jsref/tryit.asp?filename=tryjsref_ondblclick');

        // Wait for the iframe to load
        cy.frameLoaded('#iframeResult');  // Ensure iframe is fully loaded

        // Ensure the iframe is accessible and the paragraph inside it is available
        cy.iframe('#iframeResult').find('p').contains('Double-click this paragraph to trigger a function.')
            .trigger('dblclick', { force: true });  // Force the double-click event inside the iframe

        cy.iframe('#iframeResult').find('#demo').should('contain.text', 'Hello World');
    });

    it('Drag and Drop', () => {
        cy.visit('https://www.globalsqa.com/demo-site/draganddrop/#Photo%20Manager');
        
        // Wait for the iframe to be loaded (if applicable)
        cy.frameLoaded('#post-2669 > div.twelve.columns > div > div > div.single_tab_div.resp-tab-content.resp-tab-content-active > p > iframe');
        
        // Interact with elements inside the iframe
        cy.iframe('#post-2669 > div.twelve.columns > div > div > div.single_tab_div.resp-tab-content.resp-tab-content-active > p > iframe').find('#trash > ul > li > img').should('be.visible');
        
        // Perform the drag-and-drop action inside the iframe
        cy.iframe('#post-2669 > div.twelve.columns > div > div > div.single_tab_div.resp-tab-content.resp-tab-content-active > p > iframe').find('#gallery > li:nth-child(1)').drag('#trash > ul > li > img');
      });

      it.only('Drag and Drop', () => {
        cy.visit('https://testpages.eviltester.com/styled/drag-drop-javascript.html');
        cy.wait(5000); // Wait for 5 seconds to ensure elements are loaded properly.
    
        // First drag: Drag from the source (#draggable1) to the target (#droppable1)
        cy.get('#draggable1').drag('#droppable1', { force: true });
    
        cy.wait(5000); // Wait for the drop action to complete.
    
        // Second drag: Drag from the target (#droppable1) back to the source (#draggable1)
        cy.get('#droppable1').drag('#draggable1', { force: true });
    
        // Assert that the source element has the class "draggable" after the drag
        cy.get('#draggable1').should('have.class', 'draggable'); // Correctly check class without dot
    
        // Optionally, check if the target element has received any updates after the drop
        cy.get('#droppable1').should('have.class', 'droppable'); // Adjust based on your app's behavior (check for any visual changes)
    });
    
          }); 
