describe('Navigation', () => {

    it('Navigation Test pages', () => {
        cy.visit('https://www.youtube.com/results?search_query=what+is+unique+code+and+why+we+can+use+it%3F+in+javascript')
        cy.wait(5000)
        cy.get('#center > yt-searchbox > div.ytSearchboxComponentInputBox.ytSearchboxComponentInputBoxDark > form > input').type('Cypress testing{enter}');
        cy.get('#center > yt-searchbox > div.ytSearchboxComponentInputBox.ytSearchboxComponentInputBoxDark > form > input')
        cy.wait(5000)

        cy.go('back');  // javascript page
        cy.wait(3000)

        cy.go('forward') // cypress page
        cy.wait(3000)

        cy.go(-1)     // javascript page
        cy.wait(3000)

        cy.go(1)   // cypress page
        cy.wait(2000)

        cy.reload();    // reload the current page
    })
})